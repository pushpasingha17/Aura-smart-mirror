
<?php
$mood = $_POST['mood'];
file_put_contents("mood.txt", $mood);
echo "Mood updated!";
?>
