
function askAura() {
    fetch('/api/music?mood=happy')
        .then(response => response.json())
        .then(data => {
            let audio = document.getElementById('auraResponse');
            audio.src = data.preview_url;
            audio.play();
        });
}
