
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomeScreen from './screens/HomeScreen';
import MoodTracker from './screens/MoodTracker';
import MeTime from './screens/MeTime';
import Sleep from './screens/Sleep';
import { FirebaseProvider } from './firebase/FirebaseContext';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <FirebaseProvider>
      <NavigationContainer>
        <Tab.Navigator>
          <Tab.Screen name="Home" component={HomeScreen} />
          <Tab.Screen name="Mood" component={MoodTracker} />
          <Tab.Screen name="Me-Time" component={MeTime} />
          <Tab.Screen name="Sleep" component={Sleep} />
        </Tab.Navigator>
      </NavigationContainer>
    </FirebaseProvider>
  );
}
