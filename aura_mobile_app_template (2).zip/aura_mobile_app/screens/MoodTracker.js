
import React, { useEffect, useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { useFirebase } from '../firebase/FirebaseContext';

export default function MoodTracker() {
  const { logMood, getMoodData } = useFirebase();
  const [mood, setMood] = useState(null);

  const handleMood = async (m) => {
    await logMood(m);
    setMood(m);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>How do you feel today?</Text>
      {['Happy', 'Sad', 'Tired', 'Anxious'].map(m => (
        <Button title={m} onPress={() => handleMood(m)} key={m} />
      ))}
      {mood && <Text style={styles.mood}>Mood logged: {mood}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fffafc'
  },
  text: {
    fontSize: 18, marginBottom: 20, color: '#d81b60'
  },
  mood: {
    marginTop: 20, fontSize: 16, color: 'gray'
  }
});
