
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function HomeScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>🌞 Mood of the Day</Text>
      <Text style={styles.text}>📝 Planner Preview</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#ffe4f2'
  },
  text: {
    fontSize: 20, color: '#e91e63', marginBottom: 10
  }
});
