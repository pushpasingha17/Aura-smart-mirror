
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function Sleep() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>🌙 Sleep Tracker</Text>
      <Text style={styles.text}>💤 Tips & Wind-down</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#ede7f6'
  },
  text: {
    fontSize: 18, color: '#512da8', marginBottom: 10
  }
});
