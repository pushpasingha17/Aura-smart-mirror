
import React, { createContext, useContext } from 'react';
import { db } from './firebase';
import { addDoc, collection, Timestamp } from 'firebase/firestore';

const FirebaseContext = createContext();

export function FirebaseProvider({ children }) {
  const logMood = async (mood) => {
    await addDoc(collection(db, "moods"), {
      mood, createdAt: Timestamp.now()
    });
  };

  const getMoodData = async () => {
    // Load mood history from Firestore
  };

  return (
    <FirebaseContext.Provider value={{ logMood, getMoodData }}>
      {children}
    </FirebaseContext.Provider>
  );
}

export const useFirebase = () => useContext(FirebaseContext);
